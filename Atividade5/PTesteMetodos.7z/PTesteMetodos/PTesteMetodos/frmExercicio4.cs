﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumericos_Click(object sender, EventArgs e)
        {

            int contador = 0;
            int contNum = 0;
            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contNum++;
                }
                contador++;
            }
            MessageBox.Show("O texto possui "+contNum+" caracteres numéricos!");
        }

        private void btnPrimeiroBranco_Click(object sender, EventArgs e)
        {
            //int contador = 0, contNum = 0;
            //if (int = 0; rchtxtFrase)
        }
    }
}
