﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício1>().Count() > 0)
            {
                Application.OpenForms["frmExercício1"].BringToFront();
            }
            else
            {
                frmExercício1 frm1 = new frmExercício1();
                frm1.MdiParent = this;
                frm1.WindowState = FormWindowState.Maximized;
                frm1.Show();
            }
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício2>().Count() > 0)
            {
                Application.OpenForms["frmExercício2"].BringToFront();
            }
            else
            {
                frmExercício2 frm2 = new frmExercício2();
                frm2.MdiParent = this;
                frm2.WindowState = FormWindowState.Maximized;
                frm2.Show();
            }
        }

        private void exercícioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício3>().Count() > 0)
            {
                Application.OpenForms["frmExercício3"].BringToFront();
            }
            else
            {
                frmExercício3 frm3 = new frmExercício3();
                frm3.MdiParent = this;
                frm3.WindowState = FormWindowState.Maximized;
                frm3.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício4>().Count() > 0)
            {
                Application.OpenForms["frmExercício4"].BringToFront();
            }
            else
            {
                frmExercício4 frm4 = new frmExercício4();
                frm4.MdiParent = this;
                frm4.WindowState = FormWindowState.Maximized;
                frm4.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
