﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercício1 : Form
    {
        public frmExercício1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int emBranco=0;
            foreach(int x in rchtxtFrase.Text)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[x]))
                {
                    emBranco = +1;
                }
                MessageBox.Show($"O texto possui {emBranco} espaços em branco");
            }
        }

        private void btnRs_Click(object sender, EventArgs e)
        {
            int comparaR=0;
            rchtxtFrase.Text.ToUpper();
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (rchtxtFrase.Text[i] == 'R')
                {
                    comparaR =+ 1;
                }
            }
            MessageBox.Show($"O texto possui {comparaR} letras R");
        }

        private void btnSeguidas_Click(object sender, EventArgs e)
        {
            int contRep=0;
            int i=0;
            while (i < rchtxtFrase.Text.Length - 1)
            {
                if (rchtxtFrase.Text[i] == rchtxtFrase.Text[i + 1])
                {
                    contRep++;
                }
                i++;
            }
            MessageBox.Show($"O textp possui {contRep} pares de letras");
        }

        private void rchtxtFrase_Validated(object sender, EventArgs e)
        {
            if (rchtxtFrase.Text == string.Empty)
            {
                MessageBox.Show("Insira uma frase válida!");
                rchtxtFrase.Focus();
            }
        }
    }
}
