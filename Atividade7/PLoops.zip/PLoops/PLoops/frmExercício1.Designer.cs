﻿namespace PLoops
{
    partial class frmExercício1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnRs = new System.Windows.Forms.Button();
            this.btnSeguidas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(100, 76);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(561, 120);
            this.rchtxtFrase.TabIndex = 2;
            this.rchtxtFrase.Text = "";
            this.rchtxtFrase.Validated += new System.EventHandler(this.rchtxtFrase_Validated);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(256, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Insira uma frase de até 100 caracteres";
            // 
            // btnBranco
            // 
            this.btnBranco.Location = new System.Drawing.Point(100, 284);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(183, 90);
            this.btnBranco.TabIndex = 5;
            this.btnBranco.Text = "Conte espaços em branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnRs
            // 
            this.btnRs.Location = new System.Drawing.Point(289, 284);
            this.btnRs.Name = "btnRs";
            this.btnRs.Size = new System.Drawing.Size(183, 90);
            this.btnRs.TabIndex = 6;
            this.btnRs.Text = "Quantidade de \"R\"s";
            this.btnRs.UseVisualStyleBackColor = true;
            this.btnRs.Click += new System.EventHandler(this.btnRs_Click);
            // 
            // btnSeguidas
            // 
            this.btnSeguidas.Location = new System.Drawing.Point(478, 284);
            this.btnSeguidas.Name = "btnSeguidas";
            this.btnSeguidas.Size = new System.Drawing.Size(183, 91);
            this.btnSeguidas.TabIndex = 7;
            this.btnSeguidas.Text = "Letras seguidas";
            this.btnSeguidas.UseVisualStyleBackColor = true;
            this.btnSeguidas.Click += new System.EventHandler(this.btnSeguidas_Click);
            // 
            // frmExercício1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSeguidas);
            this.Controls.Add(this.btnRs);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rchtxtFrase);
            this.Enabled = false;
            this.Name = "frmExercício1";
            this.Text = "frmExercício1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnRs;
        private System.Windows.Forms.Button btnSeguidas;
    }
}