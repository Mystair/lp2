﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        frmExercicio4 obj4 = new frmExercicio4();
        

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for (int i = 0; i < vetor.Length; i ++)
            {
                auxiliar = Interaction.InputBox("Digite o número: ", "Entrada de dados");
                if (auxiliar == null)
                {
                    break;
                }
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";

            foreach (int x in vetor)
            {
                auxiliar += x+"\n";
            }
            MessageBox.Show(auxiliar);

            /*ou
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);*/
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20,3];
            string auxiliar = "";
            double media = 0;
            string stringona = "";

            for (int i = 0; i < 3; i++)
            {
                media = 0;
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}ª nota do aluno {i + 1}", "Entrada de Notas");
                    if (!double.TryParse(auxiliar, out notas[i, j]) || (notas[i, j] < 0) || (notas[i, j] > 10))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                media = media / 3;
                stringona += $"Aluno {i+1}: Média: {media.ToString("N2")} \n";
            }
            MessageBox.Show(stringona);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            obj4.Show();
        }
    }
}
