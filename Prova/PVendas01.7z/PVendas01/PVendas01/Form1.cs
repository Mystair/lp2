﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] mesSemana = new double[3, 4];
            string auxiliar = "";
            double totalGeral = 0;
            double totalMes = 0;

            for (int i = 0; i < 3; i++)
            {
                totalMes = 0;
                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o mês {i + 1}, semana {j + 1}");
                    if( !double.TryParse( auxiliar, out mesSemana[i,j] ))
                    {
                        MessageBox.Show("Número inválido!");
                        j--;
                    }
                    else
                    {
                        totalMes += mesSemana[i, j];
                        lstbxTotal.Items.Add($"Total do mês {i+1}, Semana {j+1}: {mesSemana[i,j].ToString("N2")}");
                    }
                }
                lstbxTotal.Items.Add($">> Total do mês {i+1}: {totalMes.ToString("N2")}");
                lstbxTotal.Items.Add("---------------------------------------------------");
                totalGeral += totalMes;
            }
            lstbxTotal.Items.Add($">>Total Geral: {totalGeral.ToString("N2")}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxTotal.Items.Clear();
        }
    }
}
