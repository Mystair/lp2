﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;
        

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorB.Text, out valorB))
            {
                MessageBox.Show("Insira um valor maior que zero!");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorC.Text, out valorC))
            {
                MessageBox.Show("Insira um valor maior que zero!");
                txtValorC.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear(); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (valorA > 0 && valorB > 0 && valorC > 0)
            {
                if (valorA == valorB && valorA == valorC && valorC == valorB)
                {
                    MessageBox.Show("Triângulo Equilátero");
                }
                else if (valorA != valorB && valorA != valorC && valorB != valorC)
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
                else
                {
                    MessageBox.Show("Triângulo Isósceles");
                }
            }else
                MessageBox.Show("ERRO! Os valores precisam ser maiores que zero!");
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorA.Text, out valorA))
            {
                MessageBox.Show("Insira um valor maior que zero!");
                txtValorA.Focus();
            }
        }
    }
}
