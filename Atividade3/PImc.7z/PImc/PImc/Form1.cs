﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double altura, pesoAtual, imc;

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Insira um valor de altura válida");
                mskbxAltura.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPesoAtual.Clear();
            mskbxAltura.Clear();
            mskbxIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = pesoAtual / (altura * altura);
            imc = Math.Round(imc, 1);
            imc.ToString("N1");
            if (imc < 18.5)
            {
                mskbxIMC.Text = "Magreza; IMC: " + imc;
            }
            else if (imc >= 18.5 && imc <= 24.9)
            {
                mskbxIMC.Text = "Normal; IMC: " + imc;
            }
            else if (imc >= 25 && imc <= 29.9)
            {
                mskbxIMC.Text = "Sobrepeso; IMC: " + imc;
            }else if (imc >= 30 && imc <= 39.9)
            {
                mskbxIMC.Text = "Obeisdade; IMC: " + imc;
            }
            else
            {
                mskbxIMC.Text = "Obesidade Grave; IMC: " + imc;
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPesoAtual_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(mskbxPesoAtual.Text, out pesoAtual))
            {
                MessageBox.Show("Insira um valor de altura válida");
                mskbxPesoAtual.Focus();
            }
        }
    }
}
